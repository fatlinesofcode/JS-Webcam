For documentation see: https://github.com/Digigizmo/JS-Webcam
